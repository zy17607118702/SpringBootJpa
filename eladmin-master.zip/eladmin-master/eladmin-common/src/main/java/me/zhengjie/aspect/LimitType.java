package me.zhengjie.aspect;

public enum LimitType {
    CUSTOMER,
//     by ip addr
    IP;
}
