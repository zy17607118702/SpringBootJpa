package me.zhengjie.modules.security.security;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author Zheng Jie
 * @date 2019-6-5 17:29:57
 */
@Data
@AllArgsConstructor
public class ImgResult {

    private String img;

    private String uuid;
}
